import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab',
  templateUrl: './bottomnav.page.html',
  styleUrls: ['./bottomnav.page.scss'],
})
export class TabPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
